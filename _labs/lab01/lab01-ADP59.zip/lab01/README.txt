This is CS447 - Lab01, assignment submitted by Anthony Poerio (adp59@pitt.edu).
included are two (2) files.
- One (1) MIPS Assembly program [lab01.asm]
- One (1) text file containing answers to the assignment prompt [lab01_questions.txt].

